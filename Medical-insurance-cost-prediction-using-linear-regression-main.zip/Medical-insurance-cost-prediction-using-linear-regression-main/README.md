# Medical-insurance-cost-prediction-using-linear-regression
This is a medical insurance cost prediction model that uses a linear regression algorithm to predict the medical insurance
charges of a person based on the given data. The dataset used for this tutorial is available on Kaggle and GitHub. 

To see the complete video explanation on this topic, check out the following link:
https://www.youtube.com/watch?v=iS_iI7btRXk&list=PLNohRKRAHaszuDbT6oSNhD91kpqI18G7d&index=7
